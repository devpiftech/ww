
// Re-export BaseSlotMachine from its new location for backward compatibility
import BaseSlotMachine from './base/BaseSlotMachine';
export default BaseSlotMachine;
