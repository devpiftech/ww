
// This file now re-exports from the new modular structure
// for backward compatibility
export { checkWin } from './winLogic';
