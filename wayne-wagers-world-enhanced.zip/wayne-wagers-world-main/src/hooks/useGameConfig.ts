
export { useGameConfig } from './gameConfig/useGameConfig';
export type { UseGameConfigProps } from './gameConfig/types';
