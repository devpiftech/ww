
// Re-export all functionalities from the new modular structure
export * from './gameResults';
